package com.tlneon.trashcraft;

import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Random;

public class EventHandler {
    private final Random rand = new Random();
    private int tickCounter = 0;

    @SubscribeEvent
    public void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        tickCounter++;
        if (tickCounter >= 1200) {
            tickCounter = 0;
            ServerWorld world = e.getServer().getWorld(World.OVERWORLD);
            switch (rand.nextInt(6)) {
                case 0 -> world.getPlayers().forEach(p -> p.sendMessage(new StringTextComponent("🚨 ТРЕШ-АЛЕРТ!"), p.getUniqueID()));
                case 1 -> world.createExplosion(null, rand.nextDouble()*100, rand.nextDouble()*100, rand.nextDouble()*100, 2.0f, Explosion.Mode.NONE);
                case 2 -> world.getPlayers().forEach(p -> p.abilities.disableDamage = !p.abilities.disableDamage);
                case 3 -> world.getPlayers().forEach(p -> p.playSound(SoundEvents.ENTITY_PIG_AMBIENT, 1f, 0.5f));
                case 4 -> world.getPlayers().forEach(p -> p.attemptTeleport(p.getPosX() + rand.nextInt(51)-25, p.getPosY(), p.getPosZ() + rand.nextInt(51)-25, false));
                case 5 -> world.getPlayers().forEach(p -> p.setInvisible(!p.isInvisible()));
            }
        }
    }

    @SubscribeEvent
    public void onBreak(BlockEvent.BreakEvent e) {
        if (rand.nextInt(5) == 0) {
            for (int i = 0; i < 20; i++) {
                ChickenEntity chicken = new ChickenEntity(e.getWorld().getWorld());
                chicken.setPosition(e.getPos().getX(), e.getPos().getY(), e.getPos().getZ());
                e.getWorld().addEntity(chicken);
            }
        }
    }

    @SubscribeEvent
    public void onPlayer(PlayerEvent.PlayerTickEvent e) {
        if (!(e.player instanceof ServerPlayerEntity p)) return;
        if (p.isSneaking()) {
            World world = p.world;
            p.playSound(SoundEvents.BLOCK_CAMPFIRE_CRACKLE, 1f, 1f);
            p.addVelocity(0, 1.5, 0);
            p.velocityChanged = true;
        }
    }
}
}
