package com.youruser.trashcraft;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.common.MinecraftForge;

@Mod("trashcraftforge")
public class TrashCraftForge {
    public TrashCraftForge() {
        MinecraftForge.EVENT_BUS.register(new EventHandler());
    }
}
